<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta content="name" author="Pedro Martin Escuela" >
        <title>Log-in</title>
    </head>
    <body class="antialiased">
        <form action="">
            <label for="log-in">Nombre de Usuario</label>
            <input type="text" name="log-in">
            <input type="submit" value="Log-In">
        </form>
    </body>
</html>
<?php /**PATH /home/dam/PeterMartEsc/AED/1erTrimestre/laravel/practicas-clase/miniforo/resources/views/welcome.blade.php ENDPATH**/ ?>