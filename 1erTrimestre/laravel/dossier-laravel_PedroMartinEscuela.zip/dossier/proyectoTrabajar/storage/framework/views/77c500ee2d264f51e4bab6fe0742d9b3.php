<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    </head>
    <body class="antialiased">

        <div class="crearFichero">
            <form action="/subirFile" enctype='multipart/form-data'>
                <?php echo csrf_field(); ?>
                <label for="fichero">Nombre fichero</label>
                <input type="text" name="fichero" id="fichero">

                <label for="nombre">Nombre</label>
                <input type="text" name="nombre", id="nombre">

                <label for="correo">Correo</label>
                <input type="text" name="correo" id="correo">
                
                <input type="submit" value="Crear">
                </form>
        </div>

    </body>

</html>
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel\dossier\proyectoTrabajar\resources\views/Pr18_formCrearFichero.blade.php ENDPATH**/ ?>