<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    </head>
    <body class="antialiased">

        <ul>
            <form action="/deleteFile">
                <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>· <?php echo e($archivo); ?></li>
                <input type="hidden" name="archivo" value="<?php echo e($archivo); ?>"/>
                <input type="submit" value="Borar"/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></form>
        </ul>

    </body>

</html>
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel\dossier\proyectoTrabajar\resources\views/Pr20_verFiles.blade.php ENDPATH**/ ?>