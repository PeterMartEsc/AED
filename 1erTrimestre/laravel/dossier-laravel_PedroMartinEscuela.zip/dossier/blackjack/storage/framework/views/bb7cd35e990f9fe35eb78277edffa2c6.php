<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <style>
            .perfil{
                width: 200px;
                height: 100px;
                border: solid 2px;

                padding: 10px
            }
        </style>

    </head>
    <body class="antialiased">
        <div class="perfil">
            <h2 class="miPerfil">Mi Perfil</h2>
            <p class="username"><b>Username:</b> <?php echo e(session()->get('username')); ?></p>
        </div>

        </br>

        <div class="partida">

            <div class="init">
                <form action="/start">
                    <input type="submit" name="empezar" value="Empezar/Reiniciar">
                </form>
            </div>

            <div class="manoCuprier">
                <!--Cuprier's hand is only showed because of testing interest-->
                <?php if (!isset($partida)): ?>
                    <p>Mano del cuprier: <b>No hay partida iniciada.</b></p>
                <?php else: ?>
                    <p>Mano del cuprier: <b><?php echo e($partida->getCuprier()->getMano()); ?></b></p>
                <?php endif; ?>
            </div>

            <div class="manoJugador">
                <?php if (!isset($partida)): ?>
                    <p>Mano del cuprier: <b>No hay partida iniciada.</b></p>
                <?php else: ?>
                    <p>Tu mano: <b><?php echo e($partida->getJugador()->getMano()); ?></b></p>
                <?php endif; ?>
            </div>

            <div class="robarPlantar">
                <form action="/robar">
                    <input type="submit" name="robar" value="Robar">
                </form>
                <br>
                <form action="/plantarse">
                    <input type="submit" name="plantarse" value="Plantarse">
                </form>
            </div>

            <div class="resultado">
                <?php if ((session()->get('resultado')) == null ): ?>
                    <p> </p>
                <?php else: ?>
                    <p>El resultado es: <b><?php echo e(session()->get('resultado')); ?></b></p>
                <?php endif; ?>
            </div>
        </div>
    </body>
</html>

<!--
    1.- Que el cuprier no pueda coger más de 16 puntos
    3.-
-->
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel\practicas-clase\blackjack\resources\views/index.blade.php ENDPATH**/ ?>