CREATE DATABASE construcciones;
USE construcciones;

CREATE TABLE roles (
  id INT AUTO_INCREMENT,
  nombre VARCHAR(20) NOT NULL,
  CONSTRAINT pk_roles PRIMARY KEY (id),
  CONSTRAINT uq_roles_nombre UNIQUE (nombre)  -- Clave única para nombre en roles
);

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  password VARCHAR(250) NOT NULL,
  rol INT NOT NULL DEFAULT 1,
  CONSTRAINT pk_usuarios PRIMARY KEY (id),
  CONSTRAINT uq_usuarios_nombre UNIQUE (nombre),  -- Clave única para nombre en usuarios
  FOREIGN KEY (rol) REFERENCES roles(id)
);

CREATE TABLE tableros (
  id INT AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  nombre VARCHAR(50) NOT NULL,
  contenido VARCHAR(200),
  fecha BIGINT,
  CONSTRAINT pk_tableros PRIMARY KEY (id),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE figuras (
  id INT AUTO_INCREMENT,
  imagen BLOB,
  tipo_imagen VARCHAR(50),
  CONSTRAINT pk_figuras PRIMARY KEY (id)
);

-- Insertar valores en la tabla roles
INSERT INTO roles (id, nombre) VALUES (1, 'usuario'), (2, 'admin');
