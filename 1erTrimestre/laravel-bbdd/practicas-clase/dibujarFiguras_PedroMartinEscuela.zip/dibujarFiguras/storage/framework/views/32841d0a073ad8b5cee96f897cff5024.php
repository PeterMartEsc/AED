<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Editar Usuario</title>
        <style>

        </style>
    </head>
    <body class="antialiased">
        <div class="editUser">
            <form action="/actualizarInfoUser">

                <label for="id">Id</label>
                <input type="text" name="id" value="<?php echo e($datos[0]); ?>" readonly><br/><br/>

                <label for="nombre">Nombre de Usuario:</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo e($datos[1]); ?>" required><br/><br/>

                <label for="password">Contraseña</label>
                <input type="text" id="password" name="password" placeholder="<?php echo e($datos[2]); ?>" required><br/><br/>

                <label for="rol">Rol</label>
                <input type="text" id="rol" name="rol" value="<?php echo e($datos[3]); ?>" required><br/><br/>

                <input type="submit" value="Actualizar">

            </form>
            <a href="/administrarUsuarios">Regresar</a>
        </div>
    </body>
</html>
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel-bbdd\practicas-clase\dibujarFiguras\resources\views/editarUsuario.blade.php ENDPATH**/ ?>