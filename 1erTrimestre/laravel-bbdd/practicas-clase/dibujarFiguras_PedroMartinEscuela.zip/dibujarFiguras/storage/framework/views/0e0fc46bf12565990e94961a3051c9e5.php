<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Admin Figura</title>
        <style>
            .contenedorImagenes{
                display: flex;
                flex-wrap: wrap;
                gap: 30px;
            }
            img{

                width: 30px;
                height: 30px;
            }
        </style>
    </head>
    <body class="antialiased">

        <div class="contenedorPrincipal">

            <form action="/subirImagen" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="imagen">Selecciona una imagen:</label>
                <input type="file" name="imagen" required>
                <button type="submit">Subir Imagen</button>
            </form>
            <br><br>
            <div class="contenedorImagenes">
                <?php for($i = 0; $i < count($imagenes); $i++): ?>
                    <li>
                        <img src="data:image/jpeg;base64,<?php echo e($imagenes[$i]); ?>" alt="">
                        <form action="/borrarFigura">
                            <input type="hidden" name="nombre" value="<?php echo e($imagenes[$i]); ?>">
                            <input type="submit" value="Eliminar">
                        </form>
                        <br/>
                    </li>
                <?php endfor; ?>
            </div>
        </div>
        <a href="/game">Volver al menu principal</a>
    </body>
</html>
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel-bbdd\practicas-clase\dibujarFiguras\resources\views/adminFigur.blade.php ENDPATH**/ ?>