<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Game</title>
        <style>
            .profile{
                border: 2px solid black;
                padding: 10px;
                margin: auto;
                width: 250px;
                height: 130px;
            }

            .user{
                font-size: 20px;
            }

            .tableros{
                border: 2px solid black;
                padding: 10px;
                margin: auto;
                width: 400px;
                height: auto;
            }

            .funcionesAdmin{
                border: 2px solid black;
                padding: 10px;
                margin: auto;
                width: 200px;
                height: 100px;
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="profile">
            <p class="user"><b>Bienvenido:</b> <?php echo e(session()->get('nombre')); ?></p>
            <p><b>Rol:</b> <?php echo e(session()->get('actualRol')); ?></p>

            <form action="/logout">
                <input type="submit" value="Logout">
            </form>
        </div>

        <br/>
        <br/>

        <div class="funcionesAdmin">
            <?php if(session()->get('actualRol') == 'admin'): ?>
                <a href="/administrarUsuarios">Administrar usuarios</a>
                <a href="/actualizarFiguras">Administrar figuras</a>

            <?php endif; ?>
        </div>

        <br/>
        <br/>

        <div class="tableros">
            <h5>Tableros de <?php echo e(session()->get('nombre')); ?></h5>

            <a href="/nombrarTablero">Crear Tablero</a>
            <br/><br/>
            <?php if(null !== session()->get('tablerosNames')): ?>
                <?php $__currentLoopData = session()->get('tablerosNames'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tableroName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><form action="/editarTablero">
                        <label for="tableroName"><?php echo e($tableroName); ?></label>
                        <input type="hidden" name="tableroName" value="<?php echo e($tableroName); ?>">
                        <input type="submit" value="Editar">
                    </form></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>


    </body>
</html>
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel-bbdd\practicas-clase\dibujarFiguras\resources\views/game.blade.php ENDPATH**/ ?>