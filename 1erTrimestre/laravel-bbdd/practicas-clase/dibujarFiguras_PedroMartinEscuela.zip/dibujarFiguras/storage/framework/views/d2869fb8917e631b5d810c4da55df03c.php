<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Administrar</title>
        <style>
            .contenedorPrincipal{
                border: 2px solid black;
                padding: 10px;
                margin: auto;
                width: 250px;
                height: 300px;
            }

            form{
                display: inline;
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="contenedorPrincipal">
            <?php $__currentLoopData = $nombres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($nombre); ?>

                    <form action="/editarUser">
                        <input type="hidden" name="nombre" value="<?php echo e($nombre); ?>">
                        <input type="submit" value="Editar">
                    </form>
                    <form action="/deleteUser">
                        <input type="hidden" name="nombre" value="<?php echo e($nombre); ?>">
                        <input type="submit" value="Eliminar">
                    </form>
                </li>
                <br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </body>
</html>
<?php /**PATH C:\GitHub\2DAM\Pedro-AED\1erTrimestre\laravel-bbdd\practicas-clase\dibujarFiguras\resources\views/adminUsr.blade.php ENDPATH**/ ?>