<?php

namespace App\Http\Controllers;
use App\DAO\RolDAO;
use App\DAO\UsuarioDAO;
use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/**
  * Passw: Casa
  * ------------------
  * Pepito : 1q2w3e4r
  * Goku: 1234
  */

class Controller_usuario
{
    protected $usuarioDAO;
    protected $rolDAO;
    protected $Controller_tablero;

    public function __construct(){
        $this->usuarioDAO = new UsuarioDAO();
        $this->rolDAO = new RolDAO();
        $this->Controller_tablero = new Controller_tablero();
    }

    public function login(Request $request){

        $nombre = $request->get('nombre');

        $password = $request->get('password');

        $user = $this->usuarioDAO->findByName($nombre);

        if($user === null){
            echo "No existe usuario";
            echo "<br/><br/>";
            echo '<a href="/selectLogin">volver a hacer login</>';
            return;
        }else{

            if(Hash::check($password, $user->getPassword()) ){
                session()->put('nombre', $nombre);
            }else{
                echo "Contraseña incorrecta";
                echo "<br/><br/>";
                echo '<a href="/selectLogin">volver a hacer login</a>';
                return;
            }

        }

        $rol = $user->getRol();
        session()->put('actualRol', $rol);

        $this->Controller_tablero->obtainTableros();
        return redirect('/game');
    }

    public function register(Request $request){

        /*$request->validate()([
            'nombre' => 'required|string|max:100',
            'password' => 'required|string',
        ]);*/


        $nombre = $request->get('nombre');
        $password = $request->get('password');

        $hashedPassword = Hash::make($password);

        $usuario = new Usuario();
        $usuario->setNombre($nombre);
        $usuario->setPassword($hashedPassword);

        $rolUsuario = $this->rolDAO->findById(1);
        $rolName = $rolUsuario->getNombre();

        $usuario->setRol($rolName);

        //dd($usuario);
        $this->usuarioDAO->save($usuario);
        $mensajeRegister = "Se ha registrado correctamente";

        return view("login", compact('mensajeRegister'));
    }

    public function checkLogin(){
        $nombre = session()->get('usuario');

        if(!isset($nombre)){
            return redirect("/selectLogin");
        }

    }

    public function logout(){
        session()->flush();
        return redirect("/selectLogin");
    }

}
